using Android.App;
using Android.Content.PM;
using Microsoft.Maui;

namespace InteractivePlayer.Mobile.App;

[Activity(
    Theme = "@android:style/Theme.Material.Light.NoActionBar",
    MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    ConfigurationChanges = ConfigChanges.ScreenSize
        | ConfigChanges.Orientation
        | ConfigChanges.UiMode
        | ConfigChanges.ScreenLayout
        | ConfigChanges.SmallestScreenSize
        | ConfigChanges.Density)]
public sealed class MainActivity : MauiAppCompatActivity
{
}
