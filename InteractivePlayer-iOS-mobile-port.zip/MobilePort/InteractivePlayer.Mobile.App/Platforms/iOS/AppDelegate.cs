using Foundation;
using Microsoft.Maui;

namespace InteractivePlayer.Mobile.App;

[Register("AppDelegate")]
public sealed class AppDelegate : MauiUIApplicationDelegate
{
    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
