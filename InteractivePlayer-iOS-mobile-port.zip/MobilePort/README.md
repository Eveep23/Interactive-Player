# Interactive Player mobile port

This folder starts a separate mobile port while leaving the Windows desktop project intact.

## Reused from the PC source

`InteractivePlayer.Mobile.Core` contains the interactive data models and a platform-neutral JSON reader. It reads the segment and info documents, extracts moments and state, and merges choice moments into segments. The reader accepts streams so a future Android or iOS app can provide files using its own storage APIs.

The mobile port is touch-only. The original Windows Forms UI, LibVLC Windows player, Windows controller APIs, controller support, and desktop file selection are not included.

`InteractivePlayer.Mobile.App` is a .NET MAUI shell for Android and iOS. It can load the two JSON documents, display the current story section, navigate choices by touch, and go back through visited sections. Video playback is still a placeholder.

## Next work

1. Add mobile video playback and bind story timing to the player's position.
2. Add mobile save storage and restore the current story section.
3. Improve the interactive library and choice screen for small touch displays.
4. Build and sign the iOS app on a Mac with the required Apple toolchain.

The core models and parser are adapted from the upstream project. See `InteractivePlayer.Mobile.Core/LICENSE.txt` for the upstream attribution and license terms; the project license restricts commercial use.
