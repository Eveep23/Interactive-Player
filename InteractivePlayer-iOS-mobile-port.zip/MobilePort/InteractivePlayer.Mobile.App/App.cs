namespace InteractivePlayer.Mobile.App;

public sealed class App : Application
{
    public App()
    {
        MainPage = new MainPage();
    }
}
