using System.Text.Json;
using System.Text.Json.Serialization;

namespace InteractivePlayer.Mobile.Core;

/// <summary>
/// Parsed interactive content used by the mobile player, independent of UI and video APIs.
/// </summary>
public sealed class InteractiveContent
{
    public string? InitialSegment { get; init; }
    public string VideoId { get; init; } = string.Empty;
    public Dictionary<string, Segment> Segments { get; init; } = new(StringComparer.Ordinal);
    public Dictionary<string, List<Moment>> MomentsBySegment { get; init; } = new(StringComparer.Ordinal);
    public Dictionary<string, JsonElement> GlobalState { get; init; } = new(StringComparer.Ordinal);
    public Dictionary<string, JsonElement> PersistentState { get; init; } = new(StringComparer.Ordinal);
    public Dictionary<string, List<SegmentGroup>> SegmentGroups { get; init; } = new(StringComparer.Ordinal);
    public Dictionary<string, List<SegmentState>> SegmentStates { get; init; } = new(StringComparer.Ordinal);

    public string GetStartingSegment()
    {
        if (!string.IsNullOrWhiteSpace(InitialSegment) && Segments.ContainsKey(InitialSegment))
        {
            return InitialSegment;
        }

        return Segments.FirstOrDefault(pair => pair.Value.IsStartingSegment).Key
            ?? Segments.Keys.FirstOrDefault()
            ?? throw new InvalidDataException("The interactive contains no segments.");
    }
}

/// <summary>
/// Reads the two JSON documents used by the desktop player without depending on Windows APIs.
/// </summary>
public static class InteractiveContentReader
{
    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new SegmentGroupJsonConverter() }
    };

    public static async Task<InteractiveContent> ReadAsync(
        Stream segmentsJson,
        Stream infoJson,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(segmentsJson);
        ArgumentNullException.ThrowIfNull(infoJson);

        using var segmentsDocument = await JsonDocument.ParseAsync(segmentsJson, cancellationToken: cancellationToken);
        using var infoDocument = await JsonDocument.ParseAsync(infoJson, cancellationToken: cancellationToken);

        var root = segmentsDocument.RootElement;
        var segmentMap = GetRequiredProperty(root, "segments");
        var segments = new Dictionary<string, Segment>(StringComparer.Ordinal);

        foreach (var property in segmentMap.EnumerateObject())
        {
            var segment = JsonSerializer.Deserialize<Segment>(property.Value.GetRawText(), SerializerOptions)
                ?? throw new InvalidDataException($"Segment '{property.Name}' could not be read.");
            segment.Id = property.Name;
            segments[property.Name] = segment;
        }

        if (segments.Count == 0)
        {
            throw new InvalidDataException("The segments document contains no segments.");
        }

        var initialSegment = TryGetProperty(root, "initialSegment", out var initialSegmentElement)
            ? initialSegmentElement.GetString()
            : null;

        var video = GetVideoNode(infoDocument.RootElement);
        var videoId = GetVideoId(infoDocument.RootElement);
        var interactiveMoments = GetRequiredProperty(video, "interactiveVideoMoments");
        var valueRoot = TryGetProperty(interactiveMoments, "value", out var value)
            ? value
            : interactiveMoments;
        var momentsRoot = TryGetProperty(valueRoot, "momentsBySegment", out _)
            ? valueRoot
            : interactiveMoments;
        var momentsMap = GetRequiredProperty(momentsRoot, "momentsBySegment");
        var momentsBySegment = ReadObjectMap<List<Moment>>(momentsMap, "momentsBySegment");

        if (TryGetProperty(momentsRoot, "headerImage", out var headerImage)
            && TryGetProperty(headerImage, "url", out var headerUrl))
        {
            var url = headerUrl.GetString();
            if (!string.IsNullOrWhiteSpace(url))
            {
                foreach (var moment in momentsBySegment.Values.SelectMany(moments => moments))
                {
                    moment.HeaderImage ??= new HeaderImage { Url = url };
                }
            }
        }

        var stateHistory = TryGetProperty(momentsRoot, "stateHistory", out var stateHistoryElement)
            ? stateHistoryElement
            : default;
        var globalState = ReadState(stateHistory, "global");
        var persistentState = ReadState(stateHistory, "persistent");
        var segmentGroups = TryGetProperty(momentsRoot, "segmentGroups", out var groupsElement)
            ? ReadObjectMap<List<SegmentGroup>>(groupsElement, "segmentGroups")
            : new Dictionary<string, List<SegmentGroup>>(StringComparer.Ordinal);
        var segmentStates = TryGetProperty(momentsRoot, "segmentState", out var statesElement)
            ? ReadObjectMap<List<SegmentState>>(statesElement, "segmentState")
            : new Dictionary<string, List<SegmentState>>(StringComparer.Ordinal);

        MergeMomentsIntoSegments(segments, momentsBySegment, videoId);

        return new InteractiveContent
        {
            InitialSegment = initialSegment,
            VideoId = videoId,
            Segments = segments,
            MomentsBySegment = momentsBySegment,
            GlobalState = globalState,
            PersistentState = persistentState,
            SegmentGroups = segmentGroups,
            SegmentStates = segmentStates
        };
    }

    private static void MergeMomentsIntoSegments(
        Dictionary<string, Segment> segments,
        Dictionary<string, List<Moment>> momentsBySegment,
        string videoId)
    {
        foreach (var segment in segments.Values)
        {
            if (!momentsBySegment.TryGetValue(segment.Id, out var moments))
            {
                continue;
            }

            var tutorialMoment = moments.FirstOrDefault(moment => moment.Type == "notification:inlineTutorial");
            if (tutorialMoment is not null)
            {
                segment.TutorialMoment = tutorialMoment;
            }

            var choiceMoment = moments.FirstOrDefault(moment => moment.Type == "scene:cs_template");
            if (choiceMoment is null)
            {
                var notificationMoment = moments.FirstOrDefault(moment => moment.Notification is { Count: > 0 });
                if (notificationMoment is not null)
                {
                    segment.Notification = notificationMoment.Notification;
                }

                var impressionMoment = moments.FirstOrDefault(moment => moment.ImpressionData is not null);
                if (impressionMoment is not null)
                {
                    segment.ImpressionData = impressionMoment.ImpressionData;
                }

                continue;
            }

            segment.Choices = choiceMoment.Choices ?? choiceMoment.ChoiceSets?.FirstOrDefault();
            segment.fakechoices = choiceMoment.fakechoices;
            segment.ChoiceSets = choiceMoment.ChoiceSets;
            segment.HeaderImage = choiceMoment.HeaderImage;
            segment.HeaderText = choiceMoment.HeaderText;
            segment.AnswerSequence = choiceMoment.AnswerSequence;
            segment.CorrectIndex = choiceMoment.CorrectIndex;
            segment.Id = choiceMoment.id ?? segment.Id;

            if (videoId == "80988062")
            {
                segment.ChoiceDisplayTimeMs = choiceMoment.StartMs ?? 0;
                segment.HideChoiceTimeMs = choiceMoment.uiHideMS ?? segment.EndTimeMs;
            }
            else
            {
                segment.ChoiceDisplayTimeMs = choiceMoment.UIDisplayMS ?? 0;
                segment.HideChoiceTimeMs = choiceMoment.HideTimeoutUiMS ?? segment.EndTimeMs;
            }

            segment.TimeoutSegment = choiceMoment.TimeoutSegment;
            segment.LayoutType = choiceMoment.LayoutType;
            segment.Notification = choiceMoment.Notification;
            segment.DefaultChoiceIndex = choiceMoment.DefaultChoiceIndex;
            segment.ImpressionData = choiceMoment.ImpressionData;

            if (segment.Choices is not null)
            {
                foreach (var choice in segment.Choices)
                {
                    if (string.IsNullOrEmpty(choice.SegmentId))
                    {
                        choice.SegmentId = choice.sg ?? choice.Id;
                    }
                }
            }

            if (choiceMoment.fakechoices is { Count: > 0 })
            {
                segment.fakeChoiceDisplayTimeMs = choiceMoment.fakeuiInteractionStartMS ?? segment.ChoiceDisplayTimeMs;
                segment.fakeHideChoiceTimeMs = choiceMoment.fakeuiHideMS ?? segment.HideChoiceTimeMs;
            }
        }
    }

    private static Dictionary<string, TValue> ReadObjectMap<TValue>(JsonElement element, string name)
    {
        if (element.ValueKind != JsonValueKind.Object)
        {
            throw new InvalidDataException($"The '{name}' value must be an object.");
        }

        var result = new Dictionary<string, TValue>(StringComparer.Ordinal);
        foreach (var property in element.EnumerateObject())
        {
            var value = JsonSerializer.Deserialize<TValue>(property.Value.GetRawText(), SerializerOptions);
            if (value is not null)
            {
                result[property.Name] = value;
            }
        }

        return result;
    }

    private static Dictionary<string, JsonElement> ReadState(JsonElement stateHistory, string name)
    {
        if (stateHistory.ValueKind != JsonValueKind.Object || !TryGetProperty(stateHistory, name, out var state))
        {
            return new Dictionary<string, JsonElement>(StringComparer.Ordinal);
        }

        return JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(state.GetRawText(), SerializerOptions)
            ?? new Dictionary<string, JsonElement>(StringComparer.Ordinal);
    }

    private static JsonElement GetVideoNode(JsonElement root)
    {
        var videos = GetRequiredProperty(GetRequiredProperty(root, "jsonGraph"), "videos");
        if (videos.ValueKind != JsonValueKind.Object || !videos.EnumerateObject().MoveNext())
        {
            throw new InvalidDataException("The info document does not contain a video node.");
        }

        return videos.EnumerateObject().First().Value;
    }

    private static string GetVideoId(JsonElement root)
    {
        var paths = GetRequiredProperty(root, "paths");
        if (paths.ValueKind != JsonValueKind.Array || paths.GetArrayLength() == 0)
        {
            throw new InvalidDataException("The info document does not contain a video ID path.");
        }

        var firstPath = paths[0];
        if (firstPath.ValueKind != JsonValueKind.Array || firstPath.GetArrayLength() < 2)
        {
            throw new InvalidDataException("The info document does not contain a valid video ID path.");
        }

        return firstPath[1].ToString();
    }

    private static JsonElement GetRequiredProperty(JsonElement element, string name)
    {
        if (!TryGetProperty(element, name, out var property))
        {
            throw new InvalidDataException($"Required JSON property '{name}' is missing.");
        }

        return property;
    }

    private static bool TryGetProperty(JsonElement element, string name, out JsonElement value)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in element.EnumerateObject())
            {
                if (string.Equals(property.Name, name, StringComparison.OrdinalIgnoreCase))
                {
                    value = property.Value;
                    return true;
                }
            }
        }

        value = default;
        return false;
    }
}

internal sealed class SegmentGroupJsonConverter : JsonConverter<SegmentGroup>
{
    public override SegmentGroup? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.String)
        {
            return new SegmentGroup { Segment = reader.GetString() };
        }

        if (reader.TokenType != JsonTokenType.StartObject)
        {
            throw new JsonException($"Unexpected token when reading segment group: {reader.TokenType}.");
        }

        using var document = JsonDocument.ParseValue(ref reader);
        var element = document.RootElement;
        return new SegmentGroup
        {
            Segment = TryReadString(element, "segment"),
            Precondition = TryReadString(element, "precondition"),
            GroupSegment = TryReadString(element, "segmentGroup")
        };
    }

    public override void Write(Utf8JsonWriter writer, SegmentGroup value, JsonSerializerOptions options)
    {
        writer.WriteStartObject();
        if (value.Segment is not null) writer.WriteString("segment", value.Segment);
        if (value.Precondition is not null) writer.WriteString("precondition", value.Precondition);
        if (value.GroupSegment is not null) writer.WriteString("segmentGroup", value.GroupSegment);
        writer.WriteEndObject();
    }

    private static string? TryReadString(JsonElement element, string name)
    {
        foreach (var property in element.EnumerateObject())
        {
            if (string.Equals(property.Name, name, StringComparison.OrdinalIgnoreCase))
            {
                return property.Value.ToString();
            }
        }

        return null;
    }
}
