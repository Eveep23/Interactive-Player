using InteractivePlayer.Mobile.Core;
using Microsoft.Maui.Storage;

namespace InteractivePlayer.Mobile.App;

public sealed class MainPage : ContentPage
{
    private readonly Label _statusLabel = new();
    private readonly Label _segmentLabel = new();
    private readonly Label _videoPlaceholder = new();
    private readonly VerticalStackLayout _choices = new() { Spacing = 12 };
    private readonly Button _backButton = new() { Text = "Back", IsVisible = false };
    private readonly Stack<string> _history = new();
    private InteractiveContent? _content;
    private string? _currentSegmentKey;

    public MainPage()
    {
        Title = "Interactive Player";
        BackgroundColor = Color.FromArgb("#101014");

        var loadButton = new Button
        {
            Text = "Load interactive",
            FontAttributes = FontAttributes.Bold
        };
        loadButton.Clicked += async (_, _) => await LoadInteractiveAsync();

        _backButton.Clicked += (_, _) => GoBack();

        _statusLabel.TextColor = Colors.LightGray;
        _segmentLabel.FontSize = 22;
        _segmentLabel.FontAttributes = FontAttributes.Bold;
        _videoPlaceholder.Text = "Touch-only preview. Video playback will be added in a later step.";
        _videoPlaceholder.TextColor = Colors.LightGray;
        _videoPlaceholder.HorizontalTextAlignment = TextAlignment.Center;
        _videoPlaceholder.Padding = new Thickness(16);

        var layout = new VerticalStackLayout
        {
            Padding = new Thickness(20),
            Spacing = 16,
            Children =
            {
                new Label
                {
                    Text = "Interactive Player",
                    FontSize = 28,
                    FontAttributes = FontAttributes.Bold,
                    TextColor = Colors.White
                },
                loadButton,
                _statusLabel,
                _videoPlaceholder,
                new HorizontalStackLayout { Children = { _backButton } },
                _segmentLabel,
                _choices
            }
        };

        Content = new ScrollView { Content = layout };
    }

    private async Task LoadInteractiveAsync()
    {
        try
        {
            var segmentsFile = await FilePicker.Default.PickAsync(new PickOptions
            {
                PickerTitle = "Choose the interactive segments JSON"
            });
            if (segmentsFile is null)
            {
                return;
            }

            var infoFile = await FilePicker.Default.PickAsync(new PickOptions
            {
                PickerTitle = "Choose the interactive info JSON"
            });
            if (infoFile is null)
            {
                return;
            }

            await using var segmentsStream = await segmentsFile.OpenReadAsync();
            await using var infoStream = await infoFile.OpenReadAsync();
            _content = await InteractiveContentReader.ReadAsync(segmentsStream, infoStream);
            _history.Clear();
            _currentSegmentKey = null;

            var startKey = _content.GetStartingSegment();
            _statusLabel.Text = $"Loaded {_content.Segments.Count} story sections.";
            ShowSegment(startKey);
        }
        catch (Exception exception)
        {
            await DisplayAlert("Couldn't load interactive", exception.Message, "OK");
        }
    }

    private void ShowSegment(string segmentKey)
    {
        if (_content is null || !_content.Segments.TryGetValue(segmentKey, out var segment))
        {
            return;
        }

        _currentSegmentKey = segmentKey;
        _segmentLabel.Text = segment.HeaderText ?? segment.Id ?? "Story section";
        _backButton.IsVisible = _history.Count > 0;
        _choices.Clear();

        if (segment.Choices is { Count: > 0 })
        {
            foreach (var choice in segment.Choices)
            {
                var button = new Button
                {
                    Text = string.IsNullOrWhiteSpace(choice.Text) ? "Continue" : choice.Text,
                    HorizontalOptions = LayoutOptions.Fill
                };
                button.Clicked += (_, _) => ChooseNext(choice);
                _choices.Add(button);
            }
        }
        else if (!string.IsNullOrWhiteSpace(segment.DefaultNext))
        {
            var nextButton = new Button { Text = "Continue" };
            nextButton.Clicked += (_, _) => ChooseNext(segment.DefaultNext);
            _choices.Add(nextButton);
        }
        else
        {
            _choices.Add(new Label
            {
                Text = "No choices are defined for this section.",
                TextColor = Colors.LightGray
            });
        }
    }

    private void ChooseNext(Choice choice)
    {
        ChooseNext(choice.SegmentId ?? choice.sg ?? choice.Id);
    }

    private void ChooseNext(string? nextSegmentId)
    {
        if (_content is null || string.IsNullOrWhiteSpace(nextSegmentId))
        {
            return;
        }

        var matchingSegment = _content.Segments.FirstOrDefault(pair =>
            string.Equals(pair.Key, nextSegmentId, StringComparison.Ordinal)
            || string.Equals(pair.Value.Id, nextSegmentId, StringComparison.Ordinal));

        if (matchingSegment.Value is null)
        {
            _ = DisplayAlert("Section unavailable", "The selected story section isn't in the loaded data.", "OK");
            return;
        }

        if (_currentSegmentKey is not null)
        {
            _history.Push(_currentSegmentKey);
        }

        ShowSegment(matchingSegment.Key);
    }

    private void GoBack()
    {
        if (_history.TryPop(out var previousSegment))
        {
            ShowSegment(previousSegment);
        }
    }
}
